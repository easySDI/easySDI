<tr>
       <td>
	        <table class="header_sdi_table" width="100%">
		   <tbody>
		      <tr>
		         <td class="header_sdi_comp_title">
			 <div class="header_sdi icon-48-proxy"><?php echo JText::_( 'CORE_CPANEL_PROXY_LABEL' );?></div>
			 </td>
			 <td>&nbsp;</td>
		      </tr>
		      <tr>
		         <td colspan="2">
			    <table width="100%">
			      <tr>
		               <td class="header_sdi_comp_links">&nbsp;</td>
		               <td class="header_sdi_list">
			          <ul>
				  <li><?php printf('<a href="index.php?option=%s&amp;task=showConfigList">', 'com_easysdi_proxy'); echo JText::_( 'CORE_CPANEL_PROXY_MAIN_LABEL' ); ?></a></li>
			          </ul>
			       </td>
			       <td class="header_sdi_list">
			       <td class="header_sdi_list">&nbsp;</td>
			       <td class="header_sdi_list">&nbsp;</td>
			       </tr>
			       </table>
			 </td>
		      </tr>
		    </tbody>
		 </table>
	</td>
</tr>