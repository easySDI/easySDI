INSERT INTO `#__sdi_sys_propertytype` (ordering,state,value) 
VALUES 
(1,1,'list'),
(2,1,'multiplelist'),
(3,1,'checkbox'),
(4,1,'text'),
(5,1,'textarea'),
(6,1,'message')
;

INSERT INTO `#__sdi_sys_servicetype` (ordering,state,value) 
VALUES 
(1,1,'physical'),
(2,1,'virtual')
;