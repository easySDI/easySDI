<?php
/**
 * EasySDI, a solution to implement easily any spatial data infrastructure
 * Copyright (C) 2008 DEPTH SA, Chemin d’Arche 40b, CH-1870 Monthey, easysdi@depth.ch
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see http://www.gnu.org/licenses/gpl.html.
 */


defined('_JEXEC') or die('Restricted access');

function com_install(){

	global  $mainframe;
	$db =& JFactory::getDBO();
	
	/*if (!file_exists(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_easysdi_core'.DS.'license.txt')){
		$mainframe->enqueueMessage("Core component does not exists. Easysdi_catalog could not be installed. Please install core component first.","ERROR");
		return false;
	}*/
	
	/**
	 * Check the CORE installation
	 */
	$count = 0;
	$query = "SELECT COUNT(*) FROM `#__components` WHERE `option` ='com_easysdi_core'";
	$db->setQuery( $query);
	$count = $db->loadResult();
	if ($count == 0) {
		$mainframe->enqueueMessage("Core component does not exist. Easysdi Catalog could not be installed. Please install core component first.","ERROR");
		/**
		 * Delete components
		 */
		$query = "DELETE FROM #__components where `option`= 'com_easysdi_catalog'";
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
		}
		return false;		
	}
	
	require_once(JPATH_ADMINISTRATOR.DS.'components'.DS.'com_easysdi_core'.DS.'core'.DS.'common.easysdi.php');

	$user =& JFactory::getUser();
	$user_id = $user->get('id');
	
	$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_module` (
			  `id` bigint(20) NOT NULL AUTO_INCREMENT,
			  `guid` varchar(36) NOT NULL,
			  `code` varchar(20),
			  `name` varchar(50) NOT NULL,
			  `description` varchar(100),
			  `created` datetime NOT NULL,
			  `updated` datetime,
			  `createdby` bigint(20) NOT NULL,
			  `updatedby` bigint(20),
			  `label` varchar(50),
			  `ordering` bigint(20),
			  `value` varchar(100),
			  `currentversion` bigint(20),
			  `lastversion` bigint(20),
			  PRIMARY KEY (`id`),
			  UNIQUE KEY `guid` (`guid`),
			  UNIQUE KEY `code` (`code`)
			)";
	 		
	$db->setQuery( $query);
	if (!$db->query()) {
		$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
		return false;
	}
	
	$version = '0.0';
	$query = "SELECT currentversion FROM `#__sdi_list_module` where `code` = 'CATALOG'";
	$db->setQuery( $query);
	$version = $db->loadResult();
	if (!$version)
	{
		$version= '0.1';
		$query="INSERT INTO #__sdi_list_module (guid, code, name, description, created, createdby, label, value, currentversion) 
										VALUES ('".helper_easysdi::getUniqueId()."', 'CATALOG', 'com_easysdi_catalog', 'com_easysdi_catalog', '".date('Y-m-d H:i:s')."', '".$user_id."', 'com_sdi_catalog', 'com_sdi_catalog', '".$version."')";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "SELECT id FROM `#__sdi_list_module` where `code` = 'CATALOG'";
		$db->setQuery( $query);
		$id = $db->loadResult();
		
		/**
		 * Insert value for CATALOG_URL in configuration table
		 */
		$key='';
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_URL', 'CATALOG_URL', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'http://localhost:8081/proxy/ogc/geonetwork', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * Create and complete system tables 
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_attributetype` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `defaultpattern` varchar(200),
				  `isocode` varchar(50),
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`),
				  UNIQUE KEY `code` (`code`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "INSERT INTO #__sdi_list_attributetype (guid, code, name, description, created, createdby, label, defaultpattern, isocode) VALUES 
					('".helper_easysdi::getUniqueId()."', 'guid', 'guid', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'guid', '([A-Z0-9]{8}|-|[A-Z0-9]{4}|-|[A-Z0-9]{4}|-|[A-Z0-9]{4}|-|[A-Z0-9]{12})', 'gco:CharacterString'),
					('".helper_easysdi::getUniqueId()."', 'text', 'text', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'text', '^[a-zA-Z0-9_]{1,}$', 'gco:CharacterString'),
					('".helper_easysdi::getUniqueId()."', 'locale', 'locale', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'locale', '^[a-zA-Z0-9_]{1,}$', 'gco:LocalisedCharacterString'),
					('".helper_easysdi::getUniqueId()."', 'number', 'number', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'number', '[0-9\\.\\-]', 'gco:Decimal'),
					('".helper_easysdi::getUniqueId()."', 'date', 'date', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'date', '(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)[0-9]{2}(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)[0-9]{2}', 'gco:Date'),
					('".helper_easysdi::getUniqueId()."', 'list', 'list', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'list', '^[a-zA-Z0-9_]{1,}$', NULL),
					('".helper_easysdi::getUniqueId()."', 'link', 'link', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'link', '^[a-zA-Z0-9_]{1,}$', 'gco:CharacterString')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_relationtype` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` date NOT NULL,
				  `updated` date,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`),
				  UNIQUE KEY `code` (`code`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "INSERT INTO #__sdi_list_relationtype (guid, code, name, description, created, createdby, label) VALUES 
					('".helper_easysdi::getUniqueId()."', 'association', 'association', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'association'),
					('".helper_easysdi::getUniqueId()."', 'include', 'include', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'include')
					";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_rendertype` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` date NOT NULL,
				  `updated` date,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`),
				  UNIQUE KEY `code` (`code`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "INSERT INTO #__sdi_list_rendertype (guid, code, name, description, created, createdby, label) VALUES 
					('".helper_easysdi::getUniqueId()."', 'textarea', 'textarea', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'textarea'),
					('".helper_easysdi::getUniqueId()."', 'checkbox', 'checkbox', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'checkbox'),
					('".helper_easysdi::getUniqueId()."', 'radiobutton', 'radiobutton', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'radiobutton'),
					('".helper_easysdi::getUniqueId()."', 'list', 'list', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'list'),
					('".helper_easysdi::getUniqueId()."', 'textbox', 'textbox', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'textbox')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_renderattributetype` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `attributetype_id` bigint(20) NOT NULL,
				  `rendertype_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `attributetype_id` (`attributetype_id`),
				  KEY `rendertype_id` (`rendertype_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "INSERT INTO #__sdi_list_renderattributetype (attributetype_id, rendertype_id) VALUES 
					( 2, 1),
					( 2, 5),
					( 3, 1),
					( 3, 5),
					( 4, 1),
					( 4, 5),
					( 5, 1),
					( 5, 5),
					( 6, 2),
					( 6, 3),
					( 6, 4),
					( 7, 1),
					( 7, 5)";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * End of system tables
		 */
		
		/*
		 * Package table. Contains kind of tabs.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_package` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `csslayout` bigint(20),
				  `profile_id` bigint(20) NOT NULL,
				  `class_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`),
				  KEY `profile_id` (`profile_id`),
				  KEY `class_id` (`class_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * Profile table. Contains standard.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_profile` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36),
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `class_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `class_id` (`class_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * Class table. Contains classes defining the metadatas.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_class` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36),
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `isocode` varchar(50) NOT NULL,
				  `isextensible` tinyint(1) DEFAULT '0',
				  `issystem` tinyint(1) DEFAULT '0',
				  `package_id` bigint(20),
				  `isrootclass` tinyint(1),
				  PRIMARY KEY (`id`),
				  KEY `package_id` (`package_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * ClassRelation table. Define the relations between classes.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_classrelation` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `parent_id` bigint(20) NOT NULL,
				  `child_id` bigint(20) NOT NULL,
				  `name` varchar(50) NOT NULL,
				  `lowerbound` bigint(20) NOT NULL,
				  `upperbound` bigint(20) NOT NULL,
				  `mandatory` tinyint(1) NOT NULL,
				  `relationtype_id` bigint(20) NOT NULL DEFAULT '1',
				  `isocode` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  PRIMARY KEY (`id`),
				  KEY `parent_id` (`parent_id`),
				  KEY `child_id` (`child_id`),
				  KEY `relationtype_id` (`relationtype_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * Attribute table. Contains attributes defining the metadatas.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_attribute` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `isocode` varchar(50) NOT NULL,
				  `information` varchar(50),
				  `attributetype_id` bigint(20) NOT NULL,
				  `default` varchar(50),
				  `length` bigint(20),
				  `pattern` varchar(500),
				  `issystem` tinyint(1),
				  `isextensible` tinyint(1),
				  `type_isocode` varchar(50),
				  `codeList` varchar(200),
				  PRIMARY KEY (`id`),
				  KEY `attributetype_id` (`attributetype_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * AttributeRelation table. Define the relations between classes and attributes.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_attributerelation` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `class_id` bigint(20) NOT NULL,
				  `attribute_id` bigint(20) NOT NULL,
				  `name` varchar(50) NOT NULL,
				  `lowerbound` bigint(20) NOT NULL,
				  `upperbound` bigint(20) NOT NULL,
				  `mandatory` tinyint(1) NOT NULL,
				  `rendertype_id` bigint(20) NOT NULL,
				  `isocode` varchar(50),
				  `description` varchar(100),
				  `created` datetime NOT NULL,
				  `updated` datetime,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  PRIMARY KEY (`id`),
				  KEY `class_id` (`class_id`),
				  KEY `attribute_id` (`attribute_id`),
				  KEY `rendertype_id` (`rendertype_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		
		/*
		 * CodeValue table. Define the items attributes list type.
		 * Filling by the user interface.
		 */
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_codevalue` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
				  `created` date NOT NULL,
				  `updated` date,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20),
				  `label` varchar(50),
				  `ordering` bigint(20),
				  `isocode` varchar(50),
				  `value` varchar(50),
				  `attribute_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `attribute_id` (`attribute_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/*
		 * Constraints
		 */
		$query="ALTER TABLE `#__sdi_class`
  					ADD CONSTRAINT `#__sdi_class_ibfk_1` FOREIGN KEY (`package_id`) REFERENCES `#__sdi_package` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_classrelation`
				  ADD CONSTRAINT `#__sdi_classrelation_ibfk_1` FOREIGN KEY (`relationtype_id`) REFERENCES `#__sdi_list_relationtype` (`id`),
				  ADD CONSTRAINT `#__sdi_classrelation_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `#__sdi_class` (`id`),
				  ADD CONSTRAINT `#__sdi_classrelation_ibfk_3` FOREIGN KEY (`child_id`) REFERENCES `#__sdi_class` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_attribute`
  					ADD CONSTRAINT `#__sdi_attribute_ibfk_1` FOREIGN KEY (`attributetype_id`) REFERENCES `#__sdi_list_attributetype` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_attributerelation`
				  ADD CONSTRAINT `#__sdi_attributerelation_ibfk_1` FOREIGN KEY (`rendertype_id`) REFERENCES `#__sdi_list_rendertype` (`id`),
				  ADD CONSTRAINT `#__sdi_attributerelation_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `#__sdi_class` (`id`),
				  ADD CONSTRAINT `#__sdi_attributerelation_ibfk_3` FOREIGN KEY (`attribute_id`) REFERENCES `#__sdi_attribute` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_codevalue`
  					ADD CONSTRAINT `#__sdi_codevalue_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `#__sdi_attribute` (`id`) ON DELETE CASCADE;
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_account_attribute`
				  ADD CONSTRAINT `#__sdi_account_attribute_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`),
				  ADD CONSTRAINT `#__sdi_account_attribute_ibfk_2` FOREIGN KEY (`attribute_id`) REFERENCES `#__sdi_attribute` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_account_codevalue`
				  ADD CONSTRAINT `#__sdi_account_codevalue_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
	
		$query="ALTER TABLE `#__sdi_account_object`
				  ADD CONSTRAINT `#__sdi_account_object_ibfk_1` FOREIGN KEY (`object_id`) REFERENCES `#__sdi_object` (`id`),
				  ADD CONSTRAINT `#__sdi_account_object_ibfk_2` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_profile`
  					ADD CONSTRAINT `#__sdi_profile_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `#__sdi_class` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_package`
				  ADD CONSTRAINT `#__sdi_package_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `#__sdi_profile` (`id`),
				  ADD CONSTRAINT `#__sdi_package_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `#__sdi_class` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_objecttype`
  					ADD CONSTRAINT `#__sdi_objecttype_ibfk_1` FOREIGN KEY (`profile_id`) REFERENCES `#__sdi_profile` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
	}
	if ($version == "0.1")
	{
		$query = "INSERT INTO #__sdi_list_relationtype (guid, code, name, description, created, createdby, label) VALUES 
			('".helper_easysdi::getUniqueId()."', 'aggregation', 'aggregation', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'aggregation'),
			('".helper_easysdi::getUniqueId()."', 'composition', 'composition', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'composition'),
			('".helper_easysdi::getUniqueId()."', 'generalization', 'generalization', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'generalization')
			";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "INSERT INTO #__sdi_list_renderattributetype (attributetype_id, rendertype_id) VALUES 
				( 1, 1),
				( 1, 5)
			";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "DELETE FROM #__sdi_list_renderattributetype where `attributetype_id`= '5' and (`rendertype_id` = 4 or `rendertype_id` = 5)";
		$db->setQuery( $query);
		if (!$db->query()) 
		{
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");		
		}
		
		$query="ALTER TABLE #__sdi_classrelation ADD COLUMN classassociation_id bigint(20) DEFAULT 0";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE #__sdi_classrelation DROP COLUMN mandatory";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE #__sdi_attributerelation DROP COLUMN mandatory";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		// Update component version
		$version= '0.2';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.2")
	{
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_attributerel_profile` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `attributerelation_id` bigint(20) NOT NULL,
				  `profile_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `attributerelation_id` (`attributerelation_id`),
				  KEY `profile_id` (`profile_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE `#__sdi_attributerel_profile`
				  ADD CONSTRAINT `#__sdi_attributerel_profile_ibfk_1` FOREIGN KEY (`attributerelation_id`) REFERENCES `#__sdi_attributerelation` (`id`),
				  ADD CONSTRAINT `#__sdi_attributerel_profile_ibfk_2` FOREIGN KEY (`profile_id`) REFERENCES `#__sdi_profile` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_classrel_profile` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `classrelation_id` bigint(20) NOT NULL,
				  `profile_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `classrelation_id` (`classrelation_id`),
				  KEY `profile_id` (`profile_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE `#__sdi_classrel_profile`
				  ADD CONSTRAINT `#__sdi_classrel_profile_ibfk_1` FOREIGN KEY (`classrelation_id`) REFERENCES `#__sdi_classrelation` (`id`),
				  ADD CONSTRAINT `#__sdi_classrel_profile_ibfk_2` FOREIGN KEY (`profile_id`) REFERENCES `#__sdi_profile` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		
		// Update component version
		$version= '0.3';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.3")
	{
		$query="ALTER TABLE #__sdi_attributerelation ADD COLUMN published tinyint(1) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_classrelation ADD COLUMN published tinyint(1) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_codevalue ADD COLUMN published tinyint(1) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Update component version
		$version= '0.4';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.4")
	{
		$query="ALTER TABLE #__sdi_profile ADD COLUMN metadataid bigint(20) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Update component version
		$version= '0.5';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.5")
	{
		$query="ALTER TABLE #__sdi_attributerelation ADD COLUMN guid varchar(36);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_classrelation ADD COLUMN guid varchar(36);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_translation` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `element_guid` varchar(36) NOT NULL,
				  `language_id` bigint(20) NOT NULL,
				  `label` varchar(200) NULL,
				  `defaultvalue` varchar(4000) NULL,
				  `information` varchar(200) NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) NULL,
				  PRIMARY KEY (`id`),
				  KEY `language_id` (`language_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_translation`
  				ADD CONSTRAINT `jos_sdi_translation_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `jos_sdi_language` (`id`);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Update component version
		$version= '0.6';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.6")
	{
		// La colonne ordering doit toujours �tre NOT NULL et avoir par d�faut un 0
		$query="ALTER TABLE #__sdi_attribute MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_attributerelation MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_class MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_classrelation MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_codevalue MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_language MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_list_attributetype MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_list_codelang MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_list_relationtype MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_list_rendertype MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_object MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_objecttype MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_package MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_profile MODIFY COLUMN ordering bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Update component version
		$version= '0.7';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.7")
	{
		// La colonne ordering doit toujours �tre NOT NULL et avoir par d�faut un 0
		$query="ALTER TABLE #__sdi_translation MODIFY COLUMN defaultvalue varchar(4000) NULL";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_attribute MODIFY COLUMN `default` varchar(4000) NULL";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_defaultvalue` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `attribute_id` bigint(20) NOT NULL,
				  `codevalue_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `attribute_id` (`attribute_id`),
				  KEY `codevalue_id` (`codevalue_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_defaultvalue`
				  ADD CONSTRAINT `#__sdi_defaultvalue_ibfk_1` FOREIGN KEY (`attribute_id`) REFERENCES `#__sdi_attribute` (`id`),
				  ADD CONSTRAINT `#__sdi_defaultvalue_ibfk_2` FOREIGN KEY (`codevalue_id`) REFERENCES `#__sdi_codevalue` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		// Update component version
		$version= '0.8';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.8")
	{
		// Refaactoring pour combiner les relations
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_relation` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `parent_id` bigint(20) NOT NULL,
				  `attributechild_id` bigint(20) DEFAULT NULL,
				  `classchild_id` bigint(20) DEFAULT NULL,
				  `name` varchar(50) NOT NULL,
				  `lowerbound` bigint(20) NOT NULL,
				  `upperbound` bigint(20) NOT NULL,
				  `rendertype_id` bigint(20) DEFAULT NULL,
				  `relationtype_id` bigint(20) DEFAULT NULL,
				  `isocode` varchar(50) DEFAULT NULL,
				  `description` varchar(100) DEFAULT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) DEFAULT NULL,
				  `published` tinyint(4) NOT NULL DEFAULT '0',
				  `classassociation_id` bigint(20) DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  KEY `parent_id` (`parent_id`),
				  KEY `attributechild_id` (`attributechild_id`),
				  KEY `classchild_id` (`classchild_id`),
				  KEY `rendertype_id` (`rendertype_id`),
				  KEY `relationtype_id` (`relationtype_id`),
				  KEY `classassociation_id` (`classassociation_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_relation`
				  ADD CONSTRAINT `#__sdi_relation_ibfk_6` FOREIGN KEY (`attributechild_id`) REFERENCES `#__sdi_attribute` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `#__sdi_class` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_ibfk_2` FOREIGN KEY (`classchild_id`) REFERENCES `#__sdi_class` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_ibfk_3` FOREIGN KEY (`rendertype_id`) REFERENCES `#__sdi_list_rendertype` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_ibfk_4` FOREIGN KEY (`relationtype_id`) REFERENCES `#__sdi_list_relationtype` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_ibfk_5` FOREIGN KEY (`classassociation_id`) REFERENCES `#__sdi_class` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_relation_profile` (
			  `id` bigint(20) NOT NULL AUTO_INCREMENT,
			  `relation_id` bigint(20) NOT NULL,
			  `profile_id` bigint(20) NOT NULL,
			  PRIMARY KEY (`id`),
			  KEY `relation_id` (`relation_id`,`profile_id`),
			  KEY `profile_id` (`profile_id`)
			)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE `#__sdi_relation_profile`
				  ADD CONSTRAINT `#__sdi_relation_profile_ibfk_2` FOREIGN KEY (`profile_id`) REFERENCES `#__sdi_profile` (`id`),
				  ADD CONSTRAINT `#__sdi_relation_profile_ibfk_1` FOREIGN KEY (`relation_id`) REFERENCES `#__sdi_relation` (`id`);
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		
		// Update component version
		$version= '0.9';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.9")
	{
		$query="ALTER TABLE #__sdi_translation ADD COLUMN regexmsg varchar(200);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Lock system
		$query="ALTER TABLE #__sdi_attribute ADD COLUMN checked_out bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_attribute ADD COLUMN checked_out_time datetime;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_class ADD COLUMN checked_out bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_class ADD COLUMN checked_out_time datetime;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_relation ADD COLUMN checked_out bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_relation ADD COLUMN checked_out_time datetime;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_codevalue ADD COLUMN checked_out bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_codevalue ADD COLUMN checked_out_time datetime;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_object ADD COLUMN checked_out bigint(20) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_object ADD COLUMN checked_out_time datetime;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		// Update component version
		$version= '0.11';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.11")
	{
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_manager_object` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `account_id` bigint(20) NOT NULL,
				  `object_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `account_id` (`account_id`),
				  KEY `object_id` (`object_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query = "ALTER TABLE `#__sdi_manager_object`
					  ADD CONSTRAINT `#__sdi_manager_object_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`),
					  ADD CONSTRAINT `#__sdi_manager_object_ibfk_2` FOREIGN KEY (`object_id`) REFERENCES `#__sdi_object` (`id`);
							";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_editor_object` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `account_id` bigint(20) NOT NULL,
				  `object_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `account_id` (`account_id`),
				  KEY `object_id` (`object_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query = "ALTER TABLE `#__sdi_editor_object`
					  ADD CONSTRAINT `#__sdi_editor_object_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`),
					  ADD CONSTRAINT `#__sdi_editor_object_ibfk_2` FOREIGN KEY (`object_id`) REFERENCES `#__sdi_object` (`id`);
							";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
  
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_account_objecttype` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `account_id` bigint(20) NOT NULL,
				  `objecttype_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `account_id` (`account_id`),
				  KEY `objecttype_id` (`objecttype_id`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query = "ALTER TABLE `#__sdi_account_objecttype`
					  ADD CONSTRAINT `#__sdi_account_objecttype_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `#__sdi_account` (`id`),
					  ADD CONSTRAINT `#__sdi_account_objecttype_ibfk_2` FOREIGN KEY (`objecttype_id`) REFERENCES `#__sdi_objecttype` (`id`);
							";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_boundary` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20) DEFAULT NULL,
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100) DEFAULT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) NOT NULL DEFAULT '0',
				  `northbound` float DEFAULT NULL,
				  `southbound` float DEFAULT NULL,
				  `eastbound` float DEFAULT NULL,
				  `westbound` float DEFAULT NULL,
				  `checked_out` bigint(20) NOT NULL DEFAULT '0',
				  `checked_out_time` datetime DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		/**
		 * Insert values for CATALOG_BOUNDARY in configuration table
		 */
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_ISOCODE', 'CATALOG_BOUNDARY_ISOCODE', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'gmd:EX_GeographicBoundingBox', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_NORTH', 'CATALOG_BOUNDARY_NORTH', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'gmd:northBoundLatitude', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_SOUTH', 'CATALOG_BOUNDARY_SOUTH', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'gmd:southhBoundLatitude', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_EAST', 'CATALOG_BOUNDARY_EAST', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'gmd:eastBoundLongitude', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_WEST', 'CATALOG_BOUNDARY_WEST', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'gmd:westBoundLongitude', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_BOUNDARY_TYPE', 'CATALOG_BOUNDARY_TYPE', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, '4', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_ENCODING_CODE', 'CATALOG_ENCODING_CODE', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'UTF8', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query = "insert  into #__sdi_configuration (guid, code, name, description, created, createdby, label, value, module_id) 
											values('".helper_easysdi::getUniqueId()."', 'CATALOG_ENCODING_VAL', 'CATALOG_ENCODING_VAL', 'CATALOG', '".date('Y-m-d H:i:s')."', '".$user_id."', null, 'utf8', '".$id."')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		
		$query = "INSERT INTO #__sdi_list_attributetype (guid, code, name, description, created, createdby, label, defaultpattern, isocode) VALUES 
					('".helper_easysdi::getUniqueId()."', 'datetime', 'datetime', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'datetime', '(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)[0-9]{2}(0[1-9]|[12][0-9]|3[01])[- /.](0[1-9]|1[012])[- /.](19|20)[0-9]{2}', 'gco:DateTime'),
					('".helper_easysdi::getUniqueId()."', 'textchoice', 'textchoice', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'textchoice', '^[a-zA-Z0-9_]{1,}$', 'gco:CharacterString'),
					('".helper_easysdi::getUniqueId()."', 'localechoice', 'localechoice', NULL, '".date('Y-m-d H:i:s')."', ".$user_id.", 'localechoice', '^[a-zA-Z0-9_]{1,}$', 'gco:LocalisedCharacterString')";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE #__sdi_translation ADD COLUMN title varchar(100);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_translation ADD COLUMN content varchar(500);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query = "INSERT INTO #__sdi_list_renderattributetype (attributetype_id, rendertype_id) VALUES 
					( 8, 1),
					( 8, 5),
					( 9, 4),
					( 10, 4)";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_list_metadatastateorder` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `state_id` bigint(20) NOT NULL,
				  `nextstate_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`),
				  KEY `state_id` (`state_id`),
				  KEY `nextstate_id` (`nextstate_id`)
				)";
		 		
		$db->setQuery( $query);
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE `#__sdi_list_metadatastateorder`
				  ADD CONSTRAINT `#__sdi_list_metadatastateorder_ibfk_1` FOREIGN KEY (`state_id`) REFERENCES `#__sdi_list_metadatastate` (`id`),
				  ADD CONSTRAINT `#__sdi_list_metadatastateorder_ibfk_3` FOREIGN KEY (`nextstate_id`) REFERENCES `#__sdi_list_metadatastate` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}	

		$query = "INSERT INTO #__sdi_list_metadatastateorder (state_id, nextstate_id) VALUES 
					( 1, 2),
					( 1, 4),
					( 2, 1),
					( 2, 4),
					( 3, 1),
					( 3, 4),
					( 4, 3)";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
				  
		// Update component version
		$version= '0.12';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	if ($version == "0.12")
	{
		/**
		 * Delete "include" relationtype
		 */
		$query = "delete from #__sdi_list_relationtype WHERE code='include'";
		$db->setQuery( $query);
		if (!$db->query())
		{	
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		/**
		 * New boolean in #__sdi_objecttype for visibility
		 */
		$query="ALTER TABLE #__sdi_objecttype ADD COLUMN predefined tinyint(1) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		/**
		 * New boolean in #__sdi_metadata for visibility
		 */
		$query="ALTER TABLE #__sdi_metadata ADD COLUMN visibility_id bigint(20) NOT NULL DEFAULT 2;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_metadata`
				  ADD CONSTRAINT `#__sdi_metadata_ibfk_4` FOREIGN KEY (`visibility_id`) REFERENCES `#__sdi_list_visibility` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_history_assign` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `assigned` datetime NOT NULL,
				  `assignedby` bigint(20) NOT NULL,
				  `object_id` bigint(20) DEFAULT NULL,
				  `account_id` bigint(20) DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_metadata ADD COLUMN editor_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_relation ADD COLUMN objecttypechild_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_relation`
				  ADD CONSTRAINT `#__sdi_relation_ibfk_8` FOREIGN KEY (`objecttypechild_id`) REFERENCES `#__sdi_objecttype` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE IF NOT EXISTS `#__sdi_namespace` (
				  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(20) DEFAULT NULL,
				  `name` varchar(50) NOT NULL,
				  `description` varchar(50) DEFAULT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) NOT NULL DEFAULT '0',
				  `prefix` varchar(10) NOT NULL,
				  `uri` varchar(100) NOT NULL,
				  `issystem` tinyint(1) DEFAULT 0,
				  `checked_out` bigint(20) NOT NULL DEFAULT '0',
				  `checked_out_time` datetime DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="INSERT INTO `#__sdi_namespace` (`guid`, `name`, `description`, `created`, `createdby`, `ordering`, `prefix`, `uri`, `issystem`) VALUES
					('".helper_easysdi::getUniqueId()."', 'gml', '', '".date('Y-m-d H:i:s')."', ".$user_id.", 0, 'gml', 'http://www.opengis.net/gml', 1),
					('".helper_easysdi::getUniqueId()."', 'gmd', '', '".date('Y-m-d H:i:s')."', ".$user_id.", 1, 'gmd', 'http://www.isotc211.org/2005/gmd', 1),
					('".helper_easysdi::getUniqueId()."', 'gco', '', '".date('Y-m-d H:i:s')."', ".$user_id.", 2, 'gco', 'http://www.isotc211.org/2005/gco', 1)
					;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_attribute ADD COLUMN namespace_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_attribute`
				  ADD CONSTRAINT `#__sdi_attribute_ibfk_2` FOREIGN KEY (`namespace_id`) REFERENCES `#__sdi_namespace` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_attribute ADD COLUMN listnamespace_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_attribute`
				  ADD CONSTRAINT `#__sdi_attribute_ibfk_3` FOREIGN KEY (`listnamespace_id`) REFERENCES `#__sdi_namespace` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_class ADD COLUMN namespace_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_class`
				  ADD CONSTRAINT `#__sdi_class_ibfk_2` FOREIGN KEY (`namespace_id`) REFERENCES `#__sdi_namespace` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_relation ADD COLUMN namespace_id bigint(20);";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_relation`
				  ADD CONSTRAINT `#__sdi_relation_ibfk_7` FOREIGN KEY (`namespace_id`) REFERENCES `#__sdi_namespace` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_object ADD COLUMN previewWmsUrl varchar(400) DEFAULT '';";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_object ADD COLUMN is_free tinyint(1) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_object ADD COLUMN orderable tinyint(1) NOT NULL DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE #__sdi_object ADD COLUMN visibility_id bigint(20) NOT NULL DEFAULT 2;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_object`
				  ADD CONSTRAINT `#__sdi_object_ibfk_6` FOREIGN KEY (`visibility_id`) REFERENCES `#__sdi_list_visibility` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="CREATE TABLE  IF NOT EXISTS `#__sdi_list_topiccategory` ( 
			  	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(100) NOT NULL UNIQUE default '',
				  `name` varchar(50) NOT NULL,
				  `description` varchar(50) DEFAULT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) NOT NULL DEFAULT '0',
				  `label` varchar(100) NOT NULL default '',
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)"; 
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		$query = "INSERT INTO `#__sdi_list_topiccategory` (`guid`, `code`, `name`, `label`, `created`, `createdby`) VALUES 
				  ('".helper_easysdi::getUniqueId()."', 'farming', 'farming', 'EASYSDI_METADATA_CATEGORY_FARMING', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'biota', 'biota', 'EASYSDI_METADATA_CATEGORY_BIOTA', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'bounderies', 'bounderies', 'EASYSDI_METADATA_CATEGORY_BOUNDERIES', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'climatologyMeteorologyAtmosphere', 'climatologyMeteorologyAtmosphere', 'EASYSDI_METADATA_CATEGORY_CLIMATOLOGYMETEOROLOGYATMOSPHERE', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'economy', 'economy', 'EASYSDI_METADATA_CATEGORY_ECONOMY', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'elevation', 'elevation', 'EASYSDI_METADATA_CATEGORY_ELEVATION', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'environment', 'environment', 'EASYSDI_METADATA_CATEGORY_ENVIRONMENT', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'geoscientificinformation', 'geoscientificinformation', 'EASYSDI_METADATA_CATEGORY_GEOSCIENTIFICINFORMATION', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'health', 'health', 'EASYSDI_METADATA_CATEGORY_HEALTH', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'imageryBaseMapsEarthCover', 'imageryBaseMapsEarthCover', 'EASYSDI_METADATA_CATEGORY_IMAGERYBASEMAPSEARTHCOVER', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'intelligenceMilitary', 'intelligenceMilitary', 'EASYSDI_METADATA_CATEGORY_INTELLIGENCEMILITARY', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'inlandWaters', 'inlandWaters', 'EASYSDI_METADATA_CATEGORY_INLANDWATERS', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'location', 'location', 'EASYSDI_METADATA_CATEGORY_LOCATION', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'oceans', 'oceans', 'EASYSDI_METADATA_CATEGORY_OCEANS', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'planningCadastre', 'planningCadastre', 'EASYSDI_METADATA_CATEGORY_PLANNINGCADASTRE', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'society', 'society', 'EASYSDI_METADATA_CATEGORY_SOCIETY', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'structure', 'structure', 'EASYSDI_METADATA_CATEGORY_STRUCTURE', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'transportation', 'transportation', 'EASYSDI_METADATA_CATEGORY_TRANSPORTATION', '".date('Y-m-d H:i:s')."', ".$user_id."),
				  ('".helper_easysdi::getUniqueId()."', 'utilitiesCommunication', 'utilitiesCommunication', 'EASYSDI_METADATA_CATEGORY_UTILITIESCOMMUNICATION', '".date('Y-m-d H:i:s')."', ".$user_id.")
				";
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE  IF NOT EXISTS `#__sdi_importref` ( 
			  	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `code` varchar(100) NOT NULL,
				  `name` varchar(50) NOT NULL,
				  `description` varchar(50) DEFAULT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) NOT NULL DEFAULT '0',
				  `xslfile` varchar(200) NOT NULL,
				  `url` varchar(200),
				  `checked_out` bigint(20) NOT NULL,
				  `checked_out_time` datetime DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)"; 
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE  IF NOT EXISTS `#__sdi_objecttypelink` ( 
			  	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `parent_id` bigint(20) NOT NULL,
				  `child_id` bigint(20) NOT NULL,
				  `created` datetime NOT NULL,
				  `updated` datetime DEFAULT NULL,
				  `createdby` bigint(20) NOT NULL,
				  `updatedby` bigint(20) DEFAULT NULL,
				  `ordering` bigint(20) NOT NULL DEFAULT '0',
				  `flowdown_versioning` tinyint(1) NOT NULL DEFAULT '0',
				  `escalate_versioning_update` tinyint(1) NOT NULL DEFAULT '0',
				  `checked_out` bigint(20) NOT NULL,
				  `checked_out_time` datetime DEFAULT NULL,
				  PRIMARY KEY (`id`),
				  UNIQUE KEY `guid` (`guid`)
				)"; 
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="CREATE TABLE  IF NOT EXISTS `#__sdi_objectlink` ( 
			  	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `parent_id` bigint(20) NOT NULL,
				  `child_id` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`)
				)"; 
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE #__sdi_objecttype ADD COLUMN hasVersioning tinyint(1) DEFAULT 0;";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="CREATE TABLE  IF NOT EXISTS `#__sdi_objectversion` ( 
			  	  `id` bigint(20) NOT NULL AUTO_INCREMENT,
				  `guid` varchar(36) NOT NULL,
				  `object_id` bigint(20) NOT NULL,
				  `metadata_id` bigint(20) NOT NULL,
				  `parent_id` bigint(20),
				  `name` varchar(50) NOT NULL,
				  `description` varchar(100),
			  	  `created` datetime NOT NULL,
				  `createdby` bigint(20) NOT NULL,
				  PRIMARY KEY (`id`)
				)"; 
		$db->setQuery( $query);
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE `#__sdi_objectversion`
				  ADD CONSTRAINT `#__sdi_objectversion_ibfk_1` FOREIGN KEY (`object_id`) REFERENCES `#__sdi_object` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_objectversion`
				  ADD CONSTRAINT `#__sdi_objectversion_ibfk_2` FOREIGN KEY (`metadata_id`) REFERENCES `#__sdi_metadata` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		$query="ALTER TABLE `#__sdi_objectversion`
				  ADD CONSTRAINT `#__sdi_objectversion_ibfk_3` FOREIGN KEY (`parent_id`) REFERENCES `#__sdi_objectversion` (`id`)
				";
		$db->setQuery( $query);	
		if (!$db->query()) {
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");	
		}
		
		$query="ALTER TABLE #__sdi_attribute DROP COLUMN isocode";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		$query="ALTER TABLE #__sdi_class DROP COLUMN isocode";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
		
		// Update component version
		$version= '0.13';
		$query="UPDATE #__sdi_list_module SET currentversion = ".$version." WHERE code='CATALOG'";
		$db->setQuery( $query);
		
		if (!$db->query()) 
		{			
			$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");
			return false;
		}
	}
	/**
	 * Copy View files in Core component to allow  Menu Item Manger to find entries
	 */
		/*	mkdir(JPATH_SITE.DS.'components'.DS.'com_easysdi_core'.DS.'views'.DS.'catalog', 0700);
			mkdir(JPATH_SITE.DS.'components'.DS.'com_easysdi_core'.DS.'views'.DS.'catalog'.DS.'tmpl', 0700);
			$file = JPATH_SITE.DS.'components'.DS.'com_easysdi_catalog'.DS.'views'.DS.'catalog'.DS.'metadata.xml';
			$newfile = JPATH_SITE.DS.'components'.DS.'com_easysdi_core'.DS.'views'.DS.'catalog'.DS.'metadata.xml';
			if (!copy($file, $newfile)) {
			    $mainframe->enqueueMessage("Failed to copy VIEWS file in Core component","ERROR");
				return false;
			}
			$file = JPATH_SITE.DS.'components'.DS.'com_easysdi_catalog'.DS.'views'.DS.'catalog'.DS.'tmpl'.DS.'default.xml';
			$newfile = JPATH_SITE.DS.'components'.DS.'com_easysdi_core'.DS.'views'.DS.'catalog'.DS.'tmpl'.DS.'default.xml';
			if (!copy($file, $newfile)) {
			    $mainframe->enqueueMessage("Failed to copy VIEWS file in Core component","ERROR");
				return false;
			}
			$file = JPATH_SITE.DS.'components'.DS.'com_easysdi_catalog'.DS.'views'.DS.'catalog'.DS.'tmpl'.DS.'default.php';
			$newfile = JPATH_SITE.DS.'components'.DS.'com_easysdi_core'.DS.'views'.DS.'catalog'.DS.'tmpl'.DS.'default.php';
			if (!copy($file, $newfile)) {
			   $mainframe->enqueueMessage("Failed to copy VIEWS file in Core component","ERROR");
				return false;
			}*/
	
	$query = "DELETE FROM #__components where `option`= 'com_easysdi_catalog' ";
	$db->setQuery( $query);
	if (!$db->query()) 
	{
		$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");		
	}
			
	$query =  "insert into #__components (name,link,admin_menu_alt,`option`,admin_menu_img,params)
		values('EasySDI - Catalog','option=com_easysdi_catalog','Easysdi Catalog','com_easysdi_catalog','js/ThemeOffice/component.png','')";
	$db->setQuery( $query);
	if (!$db->query()) 
	{
		$mainframe->enqueueMessage($db->getErrorMsg(),"ERROR");		
	}
	
	$mainframe->enqueueMessage("Congratulation catalog for EasySdi is installed and ready to be used. Enjoy EasySdi Catalog!","INFO");
	return true;
}


?>