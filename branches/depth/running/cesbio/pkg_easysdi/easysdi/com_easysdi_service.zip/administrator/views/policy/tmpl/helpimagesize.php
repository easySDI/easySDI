<?php
?>
		<h2>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_IMAGE_SIZE_TITLE' ); ?>
		</h2>
		<h3>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_IMAGE_SIZE' ); ?>
		</h3>
		<p>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_IMAGE_SIZE_CONTENT' ); ?>
		</p>
		
		<?php 