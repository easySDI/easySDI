<?php
?>
		<h2>
		<?php echo JText::_(  'EASYSDI_HELP_IMAGE_SIZE_TITLE' ); ?>
		</h2>
		<h3>
		<?php echo JText::_(  'EASYSDI_HELP_IMAGE_SIZE' ); ?>
		</h3>
		<p>
		<?php echo JText::_(  'EASYSDI_HELP_IMAGE_SIZE_CONTENT' ); ?>
		</p>
		
		<?php 