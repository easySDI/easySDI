<?php
?>
		<h2>
		<?php echo JText::_(  'EASYSDI_HELP_TEMPLATE_TITLE' ); ?>
		</h2>
		<h3>
		<?php echo JText::_(  'EASYSDI_HELP_WMS_QUERY' ); ?>
		</h3>
		
		
		<textarea ROWS="8" COLS="75"><gml:Polygon xmlns:gml="http://www.opengis.net/gml" srsName="EPSG:21781">
  <gml:outerBoundaryIs>
    <gml:LinearRing>                    
      <gml:coordinates>470000,50000 470000,210000 600000,210000 600000,50000 470000,50000
      </gml:coordinates>
    </gml:LinearRing>
  </gml:outerBoundaryIs>
</gml:Polygon></textarea>
		
			<p>
			<?php 
			//echo JText::_(  'EASYSDI_HELP_TEMPLATE_FILTER_TYPE_QUERY_REM' );
			?>
			</p>
			