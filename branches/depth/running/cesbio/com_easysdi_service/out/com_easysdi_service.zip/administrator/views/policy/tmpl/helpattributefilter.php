<?php
?>
		<h2>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_ATTRIBUTE_FILTER_TITLE' ); ?>
		</h2>
		<h3>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_ATTRIBUTE_FILTER_ALL' ); ?>
		</h3>
		<p>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_ATTRIBUTE_FILTER_ALL_CONTENT' ); ?>
		</p>
		<h3>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_ATTRIBUTE_FILTER_SELECT' ); ?>
		</h3>
		<p>
		<?php echo JText::_(  'COM_EASYSDI_SERVICE_HELP_ATTRIBUTE_FILTER_SELECT_CONTENT' ); ?>
		</p>