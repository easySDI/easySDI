SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `#__sdi_user`;
DROP TABLE IF EXISTS `#__sdi_address`;
DROP TABLE IF EXISTS `#__sdi_sys_addresstype`;
DROP TABLE IF EXISTS `#__sdi_sys_civility`;

SET foreign_key_checks = 1;