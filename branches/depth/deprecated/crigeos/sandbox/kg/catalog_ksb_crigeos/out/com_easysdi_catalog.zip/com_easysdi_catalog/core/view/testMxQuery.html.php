<?php 
class HTML_testMxQuery {

	 function display($result){
	 	
	 	echo $result;
	 }
}
php?>