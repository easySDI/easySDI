<?php
defined('_JEXEC') or die('Restricted access');

class testMXQuery{
	
  function test()
  {


  	$ch = curl_init();
  	curl_setopt($ch, CURLOPT_URL, "http://localhost:8080/MXQuery/manage");
 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  	curl_setopt($ch, CURLOPT_POST, true);

  	$data =   'operationtype='.JRequest::getVar("operationtype", " ").'&'.
		            'xquerycode='.urlencode(JRequest::getVar("xquerycode", " ")).'&'.
		            'fileid='.JRequest::getVar("fileid", " ");		     


  	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  	
  	try{
  		$output = curl_exec($ch);
  	}
  	catch(Exception $e){

  		$output =  $e->getTraceAsString();
  	}
  	$info = curl_getinfo($ch);
  	curl_close($ch);

  	HTML_testMxQuery::display( $output);
    die();
  }	 
  
  function process() {
  	
  	$ch = curl_init();
  	curl_setopt($ch, CURLOPT_URL, "http://localhost:8080/MXQuery/process");
 	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  	curl_setopt($ch, CURLOPT_POST, true);

  	$data =   'url='.urlencode(JRequest::getVar("url", " ")).'&fileid='.urlencode(JRequest::getVar("fileid", " "));

  	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  	
  	try{
  		$output = curl_exec($ch);
  	}
  	catch(Exception $e){

  		$output =  $e->getTraceAsString();
  	}
  	$info = curl_getinfo($ch);
  	curl_close($ch);

  	HTML_testMxQuery::display( $output);
    die();
  }
 }
?>