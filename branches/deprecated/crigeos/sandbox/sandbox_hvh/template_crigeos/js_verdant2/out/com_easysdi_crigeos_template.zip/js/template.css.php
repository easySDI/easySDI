<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted index access' );
$jstpl = base64_decode('PGRpdiBjbGFzcz0iZGVzaWduZXIiPjxhIGhyZWY9Imh0dHA6Ly93d3cuam9vbWxhc2hhY2suY29tIiB0aXRsZT0iSm9vbWxhIDEuNSBUZW1wbGF0ZXMiPkpvb21sYSBUaGVtZXMgYW5kIFRlbXBsYXRlcyBieSBKb29tbGFzaGFjazwvYT48L2Rpdj4=');
?>

