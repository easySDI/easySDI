_________________________________________
GeoSilk icon set by Rolando Pe�ate
http://projects.opengeo.org/geosilk/_________________________________________

The GeoSilk icon set is derived from the Silk
icon set by Mark James, the Silk Companion set
by Damien Guard, and the uDig icons made by
Jody Garnett of Refractions Research. It aims
to extend the Silk icon set to address the
needs of geospatial software.

_________________________________________
Silk icon set 1.3 by Mark James
http://www.famfamfam.com/lab/icons/silk/
_________________________________________

The Silk icon set is licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]

The icons can also be used under 
Creative Commons Attribution 3.0 License with
the following requirements: "As an author, I
would appreciate a reference to my authorship
of the Silk icon set contents within a readme
file or equivalent documentation for the
software which includes the set or a subset
of the icons contained within."

This means you may use it for any purpose,
and make any changes you like.
All I ask is that you include a link back
to this page in your credits: 
[ http://www.famfamfam.com/lab/icons/silk/ ]

Are you using this icon set? Send me an email
(including a link or picture if available) to
mjames@gmail.com

Any other questions about this icon set please
contact mjames@gmail.com

_________________________________________
Damien Guard
http://www.damieng.com/icons/silkcompanion
_________________________________________

The following icons are included in GeoSilk
but originally part of Damien Guard's Silk
Companion:

bullet_start.png
bullet_stop.png
compass.png
database_copy.png
database_start.png
database_stop.png
database_wrench.png
database_yellow_start.png
database_yellow_stop.png
database_yellow.png
decline.png
erase.png
server_start.png
server_stop.png

They are licensed under a
Creative Commons Attribution 2.5 License.
[ http://creativecommons.org/licenses/by/2.5/ ]

Any questions about them should be sent to:
damieng@gmail.com