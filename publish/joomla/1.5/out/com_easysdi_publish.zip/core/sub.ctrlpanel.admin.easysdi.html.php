<tr>
        <td>
	        <table class="header_sdi_table" width="100%">
		   <tbody>
		      <tr>
		         <td class="header_sdi_comp_title">
			 <div class="header_sdi icon-48-publish"><?php echo JText::_( 'CORE_CPANEL_PUBLISH_LABEL' );?></div>
			 </td>
			 <td>&nbsp;</td>
		      </tr>
		      <tr>
		         <td colspan="2">
			    <table width="100%">
			      <tr>
		               <td class="header_sdi_comp_links">&nbsp;</td>
		               <td class="header_sdi_list">
			          <ul>
			             <li><?php printf('<a href="index.php?option=%s&amp;task=editGlobalSettings">', 'com_easysdi_publish'); echo JText::_( 'CORE_CONFIGURATION_PANEL' ); ?></a></li>
			          </ul>
			       </td>
			       <td class="header_sdi_list">
			       <td class="header_sdi_list">&nbsp;</td>
			       <td class="header_sdi_list">&nbsp;</td>
			       </tr>
			       </table>
			 </td>
		      </tr>
		    </tbody>
		 </table>
	</td>
</tr>